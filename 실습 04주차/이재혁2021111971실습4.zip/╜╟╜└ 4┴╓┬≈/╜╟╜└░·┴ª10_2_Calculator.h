class Add {
public:
    void SetValue(int, int);
    void calculate();

private:
    int num1, num2;
};
class Sub {
public:
    void SetValue(int, int);
    void calculate();

private:
    int num1, num2;
};
class Mul {
public:
    void SetValue(int, int);
    void calculate();

private:
    int num1, num2;
};
class Div {
public:
    void SetValue(int, int);
    void calculate();

private:
    int num1, num2;
};
// class�� �������� ����